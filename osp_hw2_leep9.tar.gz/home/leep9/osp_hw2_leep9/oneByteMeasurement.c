//Description: 
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/time.h>

int main(int argc, char *argv[])
{
	//Declarations
	FILE *stream; //stream for open file
	char *data[10]; //pointer that gives the location
	struct timeval start; //start time save in timeval structure
        struct timeval end;  //end time save in timeval structure
	unsigned long cost; //Time(cost) of the measurement
	long iteration = 1000; //loop iteration 1000 times
	int i, j;

	//The call to fopen() takes the path to a file to
	//open(the arugment is argv[1], the filename provided
	//by the user), followd by the access mode(the "r"
	//argument means read only). fopen returns a FILE *
	//(pointer to a stream representing the open file)
	stream = fopen(argv[1], "r");
	//If the file does not exist of fopen fials
	//print an error message
	if(stream == NULL)
	{
		perror("fopen");
		exit(EXIT_FAILURE);
	}
	//loop the measurement, because durinhg the iteration
	//the strcuture cost certain time so we want to
	//iterate 1000 times for better accuracy
	for(i = 0; i < iteration; i++)
	{	
		//This call to gettimeofday() takes the tv argument
		//(&start) and the second argument is NULL
		//because we are getting the time starting 
		//now not the time from timezones.
		gettimeofday(&start, NULL);
		//This call to fread() deos 1 byte read ad reads 10 items
		//of data, each size 1 bytes long, from stream(filename
		//provided by user) and store them at the location
		//data given by the data pointer
		j = fread(data, 1, 10, stream); 
		//This call to gettimeofday() takes the tv argument
		//(&end) and the second argument is NULL 
		//hecause we are getting the time starting 
		//now not the time from timezones
		gettimeofday(&end, NULL);
		//Calculating the costs(time) of 1 byte read in microsecond
		//The struct timeval is specified in <sys/time.h> so
		//tv_sec stands for seconds and tv_usec is microseconds
		cost = 1000000 * (end.tv_sec-start.tv_sec)
		       	+ end.tv_usec-start.tv_usec;
		//prints out the time during loop iterations
		printf("Time is %ld\n", cost);
	}

	return 0;
}

