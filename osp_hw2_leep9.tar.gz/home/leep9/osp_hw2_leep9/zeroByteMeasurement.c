//Description: This program calculates the time for 0 byte read
#include <stdio.h>
#include <sys/time.h>

int main(int argc, char *argv[])
{
	//Declarations
	char *data; //pointer that gives the location
	struct timeval start; //start time save in timeval structure 
        struct timeval end;  //end time save in timeval structure
	unsigned long cost; //Time(cost) of the measurement
	long iteration = 1000; //loop iteration 1000 times
	int i, j; 

	//loop the measurement, becaus eduring the iteration
	//the structure cost certain time so we want
	//to iterate 1000 times for better accuracy 	
	for(i = 0; i < iteration; i++)
	{
		//This call call to gettimeofday() takes the tv
		//argument(&start) and the second argument is NULL
		//because we are getting the time starting
		//now not the time from timezones.
		gettimeofday(&start, NULL);
		//This call to fread() does 0 byte read and
		//reads 1 items of data, each size 0 bytes long,
		//from NULL(stdin) and store them at the location
		//data given by the data pointer. 
		j= fread(data, 0, 1, NULL); 
		//This call to gettimeofday() takes the
		//tv argument(&end) and the second argument is NULL
		//because we are getting the time ending	
		//now not the time from timezones.
		gettimeofday(&end, NULL);
		//Calculating the costs(time) of 0 byte read in microsecond
		//The struct timeval is specified in <sys/time.h> so
		//tv_sec stands for seconds and tv_usec is microseconds
		cost = 1000000 * (end.tv_sec-start.tv_sec) +
		       	end.tv_usec-start.tv_usec;
		//prints out the time during loop iterations
		printf("Time is %ld\n", cost);
	}

	return 0;
}

